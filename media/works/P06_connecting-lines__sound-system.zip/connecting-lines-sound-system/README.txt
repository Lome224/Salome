CONNECTING LINES - SOUND SYSTEM
Salome Yichi Zhang, 2025 (New York version, THE BLANC, November 2025)

FILES
  ambidronepulse.maxpat   Main Max/MSP patch: OSC receiver and the three soundscape layers
  crossfade.maxpat        Abstraction used by the patch for the four field-recording beds (keep in the same folder)
  OSCsender_test.maxpat   Test patch that sends OSC to port 8000, for checking the receiver without sensors
  handle-sensors.ino      Arduino sketch for the Adafruit Circuit Playground (four capacitive touch pads)

SIGNAL FLOW
  Train handles (capacitive pads) -> Circuit Playground (serial, 9600 baud, every 100 ms)
  -> TouchDesigner (projections; forwards sensor values as OSC)
  -> Max/MSP (udpreceive 8000; /chan1 /chan2 /chan3, scaled from 1-200)
  -> stereo speakers

CONTROLS
  T1          Ambient melody: harmony / rest
  T2          Drum: rhythm and phaser intensity
  T3 / T4     X / Y position on a wheel that blends four ambient field recordings

SOUND FILES (not included)
  The patch expects these files next to it: Waterside.wav, Bird.wav, Lake.wav,
  Wind.wav, Kick.wav, transit1.wav. Field recordings were made with collaborator
  Malachi Del Rosario and are not redistributed here.

Requires Max 8 or later. The Arduino sketch needs the Adafruit Circuit Playground library.
